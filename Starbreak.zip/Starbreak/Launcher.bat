@echo off
title StarBreak - Command Center

:: Ensure working directory stays tied to launcher location
cd /d "%~dp0"

:: Create plugins directory if it doesn't exist
if not exist "plugins" mkdir plugins

:MENU
cls
echo ===================================================
echo                     STARBREAK                      
echo ===================================================
echo              NETWORK AND SECURITY SUITE              
echo ===================================================
echo  [1] Launch Nmap (Port AND Network Discovery)
echo  [2] Launch Wireshark (Packet Capture)
echo  [3] Launch Nslookup (DNS Lookup Tool)
echo  [4] Launch StarStrike Plugin (Guided Inputs)
echo  [5] Launch StarStrike Plugin (Custom Raw Command)
echo  [6] Exit
echo ===================================================
set CHOICE=
set /p CHOICE="Select a tool [1-6]: "

if "%CHOICE%"=="1" goto RUN_NMAP
if "%CHOICE%"=="2" goto RUN_WIRESHARK
if "%CHOICE%"=="3" goto RUN_NSLOOKUP
if "%CHOICE%"=="4" goto RUN_STARSTRIKE
if "%CHOICE%"=="5" goto RUN_CUSTOM_RAW
if "%CHOICE%"=="6" goto END

echo.
echo Invalid selection, please try again.
timeout /t 2 >nul
goto MENU


:: ===================================================
:: TOOL 1: NMAP
:: ===================================================
:RUN_NMAP
cls
echo ===================================================
echo                    MODULE: NMAP
echo ===================================================
where nmap >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo Error: Nmap is not installed or not added to PATH.
    echo Please install Nmap from nmap.org and try again.
    pause
    goto MENU
)

set NMAP_TARGET=
set /p NMAP_TARGET="Enter Target IP/Subnet (e.g. 192.168.1.1): "
if "%NMAP_TARGET%"=="" goto RUN_NMAP

set NMAP_FLAGS=
set /p NMAP_FLAGS="Enter Scan Flags (default -F for fast scan): "
if "%NMAP_FLAGS%"=="" set NMAP_FLAGS=-F

echo.
echo Executing: nmap %NMAP_FLAGS% %NMAP_TARGET%
echo ---------------------------------------------------
nmap %NMAP_FLAGS% %NMAP_TARGET%
echo ---------------------------------------------------
pause
goto MENU


:: ===================================================
:: TOOL 2: WIRESHARK
:: ===================================================
:RUN_WIRESHARK
cls
echo ===================================================
echo                 MODULE: WIRESHARK
echo ===================================================
echo Launching Wireshark graphical interface...

if exist "C:\Program Files\Wireshark\Wireshark.exe" (
    start "" "C:\Program Files\Wireshark\Wireshark.exe"
) else (
    where wireshark >nul 2>&1
    if %ERRORLEVEL% EQU 0 (
        start "" wireshark
    ) else (
        echo Error: Wireshark was not found in standard paths or PATH.
        pause
    )
)
goto MENU


:: ===================================================
:: TOOL 3: NSLOOKUP
:: ===================================================
:RUN_NSLOOKUP
cls
echo ===================================================
echo                   MODULE: NSLOOKUP
echo ===================================================
set NS_TARGET=
set /p NS_TARGET="Enter Domain or IP Address to query: "
if "%NS_TARGET%"=="" goto RUN_NSLOOKUP

echo.
echo Executing: nslookup %NS_TARGET%
echo ---------------------------------------------------
nslookup %NS_TARGET%
echo ---------------------------------------------------
pause
goto MENU


:: ===================================================
:: TOOL 4: STARSTRIKE GUIDED (NO SPACES IN ARGS)
:: ===================================================
:RUN_STARSTRIKE
cls
echo ===================================================
echo               STARSTRIKE PLUGIN ENGINE
echo ===================================================

set VICTIM=
set THREADS=
set PAYLOAD=
set TYPE=

:GET_VICTIM
set /p VICTIM="[1/4] Enter Victim Target IP (e.g. 192.168.0.1): "
if "%VICTIM%"=="" goto GET_VICTIM

set /p THREADS="[2/4] Enter Number of Threads (default 50): "
if "%THREADS%"=="" set THREADS=50

set /p PAYLOAD="[3/4] Enter Payload Size in bytes (default 65455): "
if "%PAYLOAD%"=="" set PAYLOAD=65455

set /p TYPE="[4/4] Enter Type (e.g. tcp, udp, icmp): "
if "%TYPE%"=="" set TYPE=tcp

cls
echo ===================================================
echo               LAUNCHING STARSTRIKE
echo ===================================================
echo Executing command:
echo python plugins\starstrike.py --threads%THREADS% --payloadsize%PAYLOAD% --type%TYPE% --victim%VICTIM%
echo ---------------------------------------------------
echo.

if exist "plugins\starstrike.py" (
    python "plugins\starstrike.py" --threads%THREADS% --payloadsize%PAYLOAD% --type%TYPE% --victim%VICTIM%
) else if exist "plugins\starbreak.py" (
    python "plugins\starbreak.py" --threads%THREADS% --payloadsize%PAYLOAD% --type%TYPE% --victim%VICTIM%
) else (
    echo Error: Could not find starstrike.py in plugins folder.
)

echo.
echo ---------------------------------------------------
pause
goto MENU


:: ===================================================
:: TOOL 5: STARSTRIKE CUSTOM RAW COMMAND
:: ===================================================
:RUN_CUSTOM_RAW
cls
echo ===================================================
echo            STARSTRIKE RAW COMMAND LAUNCHER
echo ===================================================
echo Type the full argument string to pass directly to starstrike.py
echo Example: --threads50 --payloadsize65455 --typetcp --victim192.168.0.1
echo ---------------------------------------------------
set RAW_ARGS=
set /p RAW_ARGS="Enter flags > "

echo.
echo Executing: python plugins\starstrike.py %RAW_ARGS%
echo ---------------------------------------------------
echo.

if exist "plugins\starstrike.py" (
    python "plugins\starstrike.py" %RAW_ARGS%
) else (
    echo Error: Could not find plugins\starstrike.py
)

echo.
echo ---------------------------------------------------
pause
goto MENU


:END
echo Goodbye!
exit /b 0